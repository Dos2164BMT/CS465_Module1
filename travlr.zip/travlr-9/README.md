# Travlr Getaways — CS 465 Module Seven

This version adds JWT authentication to the Angular administrative SPA and protects all trip create, update, and delete endpoints. The customer-facing Express site and public trip read endpoints remain available without authentication.

## Security design

- `app_api/models/user.js` stores a unique email plus a PBKDF2 password salt and hash. Plain-text passwords are never saved.
- `POST /api/register` creates an administrator account and returns a signed JWT.
- `POST /api/login` validates credentials through Passport Local and returns a signed JWT.
- Express JWT middleware requires `Authorization: Bearer <token>` for trip POST, PUT, and DELETE requests.
- The Angular SPA has an HTML login form, authentication service, route guard, HTTP interceptor, token-expiration check, and logout control.
- The interceptor adds the JWT only to `/api/` requests, while the guard prevents unauthenticated access to administrative screens.
- `.env` is excluded from source control. Set a strong `JWT_SECRET` outside the source code for normal use.

## Project structure

- `app_admin/` — Angular administrative SPA
- `app_admin/src/app/components/login/` — admin login form and logic
- `app_admin/src/app/services/authentication.ts` — login, registration API support, token storage, and expiration checks
- `app_admin/src/app/services/auth.guard.ts` — protects SPA admin routes
- `app_admin/src/app/services/auth.interceptor.ts` — adds Bearer tokens to API requests
- `app_api/models/user.js` — administrator schema, password hashing, and JWT generation
- `app_api/controllers/authentication.js` — register and login endpoint logic
- `app_api/config/passport.js` — Passport Local authentication strategy
- `tests/Travlr_Module7.postman_collection.json` — authentication and protected CRUD requests
- `tests/security.test.js` — password and JWT unit tests using mock user data
- `tests/mock-api.js` — mock security API for front-end testing without MongoDB

## Install and configure

MongoDB must be running locally. From the project folder:

```bash
npm install
npm --prefix app_admin install
```

Create a local `.env` from `.env.example`, then set a long random `JWT_SECRET`. The application loads this file automatically with `dotenv`. Never commit the real `.env` file.

Windows users can follow the exact PowerShell commands in [`WINDOWS_SETUP.md`](WINDOWS_SETUP.md). All npm scripts and application paths are cross-platform; no Bash-only command is required to install, test, build, or run the project.

Seed and run the full application:

```bash
npm run validate:data
npm run seed
npm start
```

In a second terminal:

```bash
npm run start:admin
```

Open the Angular admin at `http://localhost:4200` and the customer site at `http://localhost:3000/travel`.

## Authentication and Postman testing

1. Import `tests/Travlr_Module7.postman_collection.json` into Postman.
2. Start Express and MongoDB.
3. Run **Register administrator** once. A repeated run may correctly return HTTP 409.
4. Run **Login and save JWT**. Its test script stores the returned token as a collection variable.
5. Run **Reject trip creation without JWT** and verify HTTP 401.
6. Run the authenticated create, update, and delete requests in order.
7. Log into the Angular SPA with the registered email and password. Confirm that add, edit, and delete work.
8. Log out and confirm that protected routes redirect to `/login`.

For mock front-end testing without MongoDB, run `node tests/mock-api.js`. The mock administrator is `admin@example.com` with password `Password123!`. These credentials exist only in the mock test server.

## Validation commands

```bash
npm test
npm run build:admin
```

The automated checks cover the original API controller operations, salted password hashing, valid and invalid password comparison, JWT claims, JWT signature rejection, and Angular production compilation.

## API authorization matrix

| Method | Endpoint | Authentication |
| --- | --- | --- |
| POST | `/api/register` | Public account-creation endpoint |
| POST | `/api/login` | Public credential endpoint |
| GET | `/api/trips` | Public read |
| GET | `/api/trips/:tripCode` | Public read |
| POST | `/api/trips` | JWT required |
| PUT | `/api/trips/:tripCode` | JWT required |
| DELETE | `/api/trips/:tripCode` | JWT required |
