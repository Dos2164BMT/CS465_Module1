const assert = require('assert');
const jwt = require('jsonwebtoken');
const User = require('../app_api/models/user');

const run = () => {
  process.env.JWT_SECRET = 'module-seven-test-secret';
  const user = new User({ name: 'Mock Administrator', email: 'admin@example.com' });
  user.setPassword('Password123!');

  assert.ok(user.salt.length >= 32, 'A random salt should be generated.');
  assert.notStrictEqual(user.hash, 'Password123!', 'The plain-text password must never be stored.');
  assert.strictEqual(user.validPassword('Password123!'), true);
  assert.strictEqual(user.validPassword('WrongPassword!'), false);

  const token = user.generateJwt();
  const payload = jwt.verify(token, process.env.JWT_SECRET);
  assert.strictEqual(payload.email, 'admin@example.com');
  assert.strictEqual(payload.name, 'Mock Administrator');
  assert.ok(payload.exp > Math.floor(Date.now() / 1000));
  assert.throws(() => jwt.verify(token, 'incorrect-secret'));
  console.log('Security tests passed: password hash, password validation, JWT claims, and signature rejection.');
};

try { run(); } catch (error) { console.error(error); process.exit(1); }
