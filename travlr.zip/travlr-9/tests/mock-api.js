const express = require('express');
const path = require('path');
const seedTrips = require('../app_server/data/trips.json');
const jwt = require('jsonwebtoken');

const app = express();
let trips = seedTrips.map((trip) => ({ ...trip }));

app.use(express.json());
const mockSecret = 'mock-api-development-secret';
const mockUser = { email: 'admin@example.com', password: 'Password123!', name: 'Mock Administrator' };

const requireToken = (req, res, next) => {
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { jwt.verify(token, mockSecret); return next(); }
  catch { return res.status(401).json({ message: 'A valid authentication token is required.' }); }
};

app.use('/images', express.static(path.join(__dirname, '..', 'public', 'images')));
app.get('/travel', (req, res) => res.send('<h1>Travlr customer website test route</h1>'));
app.post('/api/register', (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'Name, email, and password are required.' });
  }
  return res.status(201).json({ token: jwt.sign({ email: req.body.email, name: req.body.name }, mockSecret, { expiresIn: '1h' }) });
});
app.post('/api/login', (req, res) => {
  if (req.body.email !== mockUser.email || req.body.password !== mockUser.password) {
    return res.status(401).json({ message: 'Email or password is incorrect.' });
  }
  return res.json({ token: jwt.sign({ email: mockUser.email, name: mockUser.name }, mockSecret, { expiresIn: '1h' }) });
});
app.get('/api/trips', (req, res) => res.json(trips));
app.get('/api/trips/:code', (req, res) => {
  const trip = trips.find((item) => item.code === req.params.code.toUpperCase());
  return trip ? res.json(trip) : res.status(404).json({ message: 'Trip not found.' });
});
app.post('/api/trips', requireToken, (req, res) => {
  const trip = { ...req.body, code: String(req.body.code).toUpperCase() };
  trips.push(trip);
  return res.status(201).json(trip);
});
app.put('/api/trips/:code', requireToken, (req, res) => {
  const index = trips.findIndex((item) => item.code === req.params.code.toUpperCase());
  if (index < 0) return res.status(404).json({ message: 'Trip not found.' });
  trips[index] = { ...req.body, code: req.params.code.toUpperCase() };
  return res.json(trips[index]);
});
app.delete('/api/trips/:code', requireToken, (req, res) => {
  trips = trips.filter((item) => item.code !== req.params.code.toUpperCase());
  return res.status(204).send();
});

app.listen(3000, () => console.log('Mock API listening on http://localhost:3000'));
