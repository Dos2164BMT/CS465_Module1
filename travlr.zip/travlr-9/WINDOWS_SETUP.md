# Windows Setup and Testing

These instructions use Windows PowerShell and work from an extracted copy of `travlr.zip`.

## Prerequisites

Install the current Node.js LTS release, MongoDB Community Server, Postman, and a code editor such as Visual Studio Code. During MongoDB installation, select the option to run MongoDB as a Windows service.

Verify the command-line tools:

```powershell
node --version
npm --version
mongosh --version
```

## Install the application

Open PowerShell, change to the extracted project directory, and install both applications:

```powershell
cd "$HOME\Downloads\travlr"
npm install
npm --prefix app_admin install
```

Create the local environment file:

```powershell
Copy-Item .env.example .env
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copy the generated value into `.env` after `JWT_SECRET=`. Do not upload or commit `.env`.

## Validate and run with MongoDB

Confirm that the MongoDB Windows service is running, then execute:

```powershell
npm run validate:data
npm run seed
npm test
npm run build:admin
npm start
```

Leave that PowerShell window open. In a second PowerShell window:

```powershell
cd "$HOME\Downloads\travlr"
npm run start:admin
```

Open:

- Admin SPA: `http://localhost:4200`
- Customer website: `http://localhost:3000/travel`

## Create the administrator and test security

Import `tests\Travlr_Module7.postman_collection.json` into Postman. Run the requests from top to bottom:

1. Register administrator
2. Login and save JWT
3. Reject trip creation without JWT
4. Create trip with JWT
5. Update trip with JWT
6. Delete trip with JWT

The login request automatically saves the returned JWT for later collection requests. Then use the same email and password at `http://localhost:4200/login` and confirm that add, edit, and delete actions work.

## Front-end mock mode

If MongoDB is not available, test the Angular authentication flow against the included mock API. In the first PowerShell window:

```powershell
npm run start:mock
```

In the second PowerShell window:

```powershell
npm run start:admin
```

Use these mock-only credentials:

- Email: `admin@example.com`
- Password: `Password123!`

The mock server requires a valid JWT for create, update, and delete operations, so it exercises the same Angular login, token, guard, interceptor, and logout behavior without MongoDB.

## Common Windows fixes

- If port 3000 is occupied, close the other Node process in Task Manager before restarting Express.
- If port 4200 is occupied, stop the other Angular development server with Ctrl+C.
- If PowerShell blocks a script, run npm through `npm.cmd`, such as `npm.cmd install` or `npm.cmd run start:admin`.
- If MongoDB cannot connect, open **Services**, find **MongoDB Server**, and select **Start**.
- Always extract the ZIP before opening or running the project; do not execute it from inside File Explorer's compressed-folder view.
