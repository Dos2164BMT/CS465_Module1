import { Routes } from '@angular/router';
import { TripList } from './components/trip-list/trip-list';
import { TripForm } from './components/trip-form/trip-form';
import { Login } from './components/login/login';
import { authGuard } from './services/auth.guard';

export const routes: Routes = [
  { path: 'login', component: Login, title: 'Login | Travlr Admin' },
  { path: '', component: TripList, canActivate: [authGuard], title: 'Trips | Travlr Admin' },
  { path: 'add', component: TripForm, canActivate: [authGuard], title: 'Add Trip | Travlr Admin' },
  { path: 'edit/:code', component: TripForm, canActivate: [authGuard], title: 'Edit Trip | Travlr Admin' },
  { path: '**', redirectTo: '' }
];
