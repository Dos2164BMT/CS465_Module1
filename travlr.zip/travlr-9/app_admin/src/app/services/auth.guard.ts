import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthenticationService } from './authentication';

export const authGuard: CanActivateFn = (_route, state) => {
  const authentication = inject(AuthenticationService);
  if (authentication.isLoggedIn()) return true;
  return inject(Router).createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
};
