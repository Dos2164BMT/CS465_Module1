import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

interface AuthResponse { token: string; }
export interface LoginCredentials { email: string; password: string; }
export interface RegisterCredentials extends LoginCredentials { name: string; }

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private readonly tokenKey = 'travlr-token';

  constructor(private readonly http: HttpClient) {}

  login(credentials: LoginCredentials): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/login', credentials)
      .pipe(tap((response) => this.saveToken(response.token)));
  }

  register(credentials: RegisterCredentials): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/register', credentials)
      .pipe(tap((response) => this.saveToken(response.token)));
  }

  logout(): void { localStorage.removeItem(this.tokenKey); }
  getToken(): string | null { return localStorage.getItem(this.tokenKey); }

  private saveToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return typeof payload.exp === 'number' && payload.exp > Date.now() / 1000;
    } catch {
      this.logout();
      return false;
    }
  }
}
