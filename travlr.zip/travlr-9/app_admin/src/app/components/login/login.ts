import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService, LoginCredentials } from '../../services/authentication';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  credentials: LoginCredentials = { email: '', password: '' };
  submitting = false;
  errorMessage = '';

  constructor(
    private readonly authentication: AuthenticationService,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {}

  login(form: NgForm): void {
    if (form.invalid) { form.control.markAllAsTouched(); return; }
    this.submitting = true;
    this.errorMessage = '';
    this.authentication.login(this.credentials).subscribe({
      next: () => this.router.navigateByUrl(this.route.snapshot.queryParamMap.get('returnUrl') || '/'),
      error: (error) => {
        this.errorMessage = error.error?.message || 'Login failed. Check your credentials.';
        this.submitting = false;
      }
    });
  }
}
