import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthenticationService } from './services/authentication';

@Component({
  selector: 'app-root',
  imports: [RouterLink, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  constructor(public readonly authentication: AuthenticationService, private readonly router: Router) {}

  logout(): void {
    this.authentication.logout();
    this.router.navigate(['/login']);
  }
}
