const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const authenticationController = require('../controllers/authentication');
const { expressjwt: jwt } = require('express-jwt');

const authenticate = jwt({
  secret: process.env.JWT_SECRET || 'travlr-development-secret-change-me',
  algorithms: ['HS256']
});

router.post('/register', authenticationController.register);
router.post('/login', authenticationController.login);

router.route('/trips')
  .get(tripsController.tripsList)
  .post(authenticate, tripsController.tripsAddTrip);

router.route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(authenticate, tripsController.tripsUpdateTrip)
  .delete(authenticate, tripsController.tripsDeleteTrip);

module.exports = router;
