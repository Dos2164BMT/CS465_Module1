const mongoose = require('mongoose');
const passport = require('passport');

const User = mongoose.model('User');

const register = async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (!name || !email || password.length < 8) {
    return res.status(400).json({ message: 'Name, email, and a password of at least 8 characters are required.' });
  }

  try {
    if (await User.findOne({ email }).exec()) {
      return res.status(409).json({ message: 'An account with that email already exists.' });
    }
    const user = new User({ name, email });
    user.setPassword(password);
    await user.save();
    return res.status(201).json({ token: user.generateJwt() });
  } catch (error) {
    return res.status(400).json({ message: 'The account could not be created.', error: error.message });
  }
};

const login = (req, res, next) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }
  return passport.authenticate('local', (error, user, info) => {
    if (error) return next(error);
    if (!user) return res.status(401).json({ message: info?.message || 'Authentication failed.' });
    return res.status(200).json({ token: user.generateJwt() });
  })(req, res, next);
};

module.exports = { register, login };
