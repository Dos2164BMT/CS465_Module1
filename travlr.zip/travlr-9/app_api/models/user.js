const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  name: { type: String, required: true, trim: true },
  hash: { type: String, required: true },
  salt: { type: String, required: true }
});

userSchema.methods.setPassword = function setPassword(password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.hash = crypto.pbkdf2Sync(password, this.salt, 100000, 64, 'sha512').toString('hex');
};

userSchema.methods.validPassword = function validPassword(password) {
  const hash = crypto.pbkdf2Sync(password, this.salt, 100000, 64, 'sha512').toString('hex');
  const stored = Buffer.from(this.hash, 'hex');
  const supplied = Buffer.from(hash, 'hex');
  return stored.length === supplied.length && crypto.timingSafeEqual(stored, supplied);
};

userSchema.methods.generateJwt = function generateJwt() {
  const expires = new Date();
  expires.setDate(expires.getDate() + 7);
  return jwt.sign({
    _id: this._id,
    email: this.email,
    name: this.name,
    exp: Math.floor(expires.getTime() / 1000)
  }, process.env.JWT_SECRET || 'travlr-development-secret-change-me');
};

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
