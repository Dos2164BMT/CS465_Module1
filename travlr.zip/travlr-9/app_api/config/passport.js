const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');

const User = mongoose.model('User');

passport.use(new LocalStrategy({ usernameField: 'email' }, async (email, password, done) => {
  try {
    const user = await User.findOne({ email: String(email).trim().toLowerCase() }).exec();
    if (!user || !user.validPassword(password)) {
      return done(null, false, { message: 'Email or password is incorrect.' });
    }
    return done(null, user);
  } catch (error) {
    return done(error);
  }
}));
